/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.dbclient;

import java.rmi.*;
public interface DBIntf extends Remote
{
    public String getData(String s, String db) throws RemoteException;
}

