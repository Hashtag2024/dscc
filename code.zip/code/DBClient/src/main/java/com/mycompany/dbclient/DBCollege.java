/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dbclient;

import java.rmi.*;
import java.rmi.server.*;
import java.sql.*;
public class DBCollege extends UnicastRemoteObject implements DBIntf{
    String str="", str1="";
    public DBCollege() throws RemoteException {}
    public String getData(String sql, String dsn) throws RemoteException {
        String URL="jdbc:mysql://localhost/"+dsn; //dsn=data source name
        try {
Class.forName("com.mysql.jdbc.Driver"); 
Connection con=DriverManager.
getConnection(URL,"root","");
System.out.println("Database Connected Successfully.");
            Statement s=con.createStatement();
            ResultSet rs=s.executeQuery(sql);
ResultSetMetaData rsmd=rs.getMetaData();
     str1="";
     str="";
for(int i=1;i<=rsmd.getColumnCount();i++) {
str1=str1+rsmd.getColumnName(i)+"\t";   }
            System.out.println();
            while(rs.next()) {
for(int i=1;i<=rsmd.getColumnCount();i++) {
                    str=str+rs.getString(i)+"\t"; }
                str=str+"\n"; } }
        catch(Exception e) {
            e.printStackTrace();  }
        return(str1+"\n"+str); }}

