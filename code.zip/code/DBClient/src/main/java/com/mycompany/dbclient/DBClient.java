/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.dbclient;

import java.rmi.*;
import java.io.*;

public class DBClient
{
    public static void main(String[] args)
    {
         String db="", sql="", ch="", ch1="", res="";
        try 
        {
            BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
            while(true)
            {
                System.out.println("Retrieve College Information.");
                db="college2";
                System.out.println("Select an option");
                System.out.println("a) Retrieve Student Information.");
                System.out.println("b) Retreive Books Information.");
                System.out.println("Enter your choice: ");
                    ch1=br.readLine();
                    if(ch1.equals("a"))
                    {
                        sql="select * from student";
                    }
                    else if(ch1.equals("b")) 
                    {
                        sql="select * from book"; 
                    }
                    else
                    {
                      System.out.println("Please select a valid option."); 
                      System.exit(0);
                    }
            
                
            DBIntf id=(DBIntf)Naming.lookup("rmi://localhost:1099/DBConn");
                res=id.getData(sql,db);
                System.out.println(res);
        }
    }
        catch (Exception e)
        {
            e.printStackTrace();
        } 
}
}

