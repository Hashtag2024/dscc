/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.calciclient;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;
public class CalciClient {
    public static void main(String[] args) throws NotBoundException, MalformedURLException, RemoteException {
        Scanner sc=new Scanner(System.in);
        try{
            CalciInterface c= (CalciInterface)Naming.lookup("rmi://localhost:1099/CalciInterface");
            System.out.println("Client is connected to server.");
            System.out.println("Please enter your choice: \n1. add\n2. sub\n3. mul\n4. div\n");
            int choice=sc.nextInt();
            int x,y;
            switch(choice){
                case 1: 
                    System.out.println("Enter x and y: ");
                    x=sc.nextInt();
                    y=sc.nextInt();
                    System.out.println(c.add(x,y));
                    break;
                     case 2: 
                    System.out.println("Enter x and y: ");
                    x=sc.nextInt();
                    y=sc.nextInt();
                    System.out.println(c.sub(x,y));
                    break;   
                case 3:
                    System.out.println("Enter x and y: ");
                    x=sc.nextInt();
                    y=sc.nextInt();
                    System.out.println(c.mul(x,y));
                    break;              
                case 4:
                    System.out.println("Enter x and y: ");
                    x=sc.nextInt();
                    y=sc.nextInt();
                    System.out.println(c.div(x,y));
                    break;    }}     
                        catch(Exception e){} }}

