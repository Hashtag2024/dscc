/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calciclient;

import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
public class Calciserver {
    public static  void main(String[] args) throws RemoteException, NotBoundException {
       Registry r=java.rmi.registry.LocateRegistry.createRegistry(1099);
       r.rebind("CalciInterface", (Remote) new CalciRMI());
       System.out.println("server is running");}}

