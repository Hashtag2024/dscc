/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.calciclient;

import java.rmi.Remote;
import java.rmi.RemoteException;
public interface CalciInterface extends Remote{public int add (int x,int y)throws RemoteException;
public int sub(int x,int y) throws RemoteException;
public int mul(int x,int y) throws RemoteException;
public int div(int x,int y) throws RemoteException;        }

