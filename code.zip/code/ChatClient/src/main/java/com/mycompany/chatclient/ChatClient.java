/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.chatclient;
import java.io.*;
import java.net.*;
public class ChatClient {
   Socket soc;
   BufferedReader br,br1;
   PrintWriter out;
   String str;
   public ChatClient()
   {
       try{
           soc=new Socket(InetAddress.getLocalHost(),9999);
           br=new BufferedReader(new InputStreamReader(System.in));
           out=new PrintWriter(soc.getOutputStream(),true);
           System.out.println("Chat client started.");
           while(true){
               str=br.readLine();
               out.println(str);
               new ChatServer(); 
           }       }
       catch(Exception e){
       }
   }
   class ChatServer extends Thread
   {
       String str1;
       ChatServer()
       {
           try{
               br1=new BufferedReader(new InputStreamReader(soc.getInputStream()));
               start();
           }
           catch(Exception e)
           {}
       }
       public void run(){
           try{
               str1=br1.readLine();
               System.out.println("Server says:"+str1);
           }
           catch(Exception e){}
       }
   }
   public static void main(String[] args)
   {
       new ChatClient();
   }}


