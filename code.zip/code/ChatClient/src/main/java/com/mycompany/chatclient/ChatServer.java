/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatclient;
import java.io.*;
import java.net.*;
public class ChatServer extends Thread{
    ServerSocket ss;
    Socket soc;
    BufferedReader br,br1;
    PrintWriter out;
    String str;
    public ChatServer()
   {
    try{
        ss=new ServerSocket(9999);
        soc=ss.accept();
         br=new BufferedReader(new InputStreamReader(soc.getInputStream()));
           out=new PrintWriter(soc.getOutputStream(),true);
           System.out.println("Chat server started.");   
           start();
           new ChatServer1();
    }
    catch(Exception e)
    {}    }
    public void run(){
        try{
            while(true)
            {
                str=br.readLine();
                System.out.println("Client says:"+str);
            }        }
        catch(Exception e)
        {}    }
   class ChatServer1{
       String str1;
       ChatServer1()
       {
               try{
                    br1=new BufferedReader(new InputStreamReader(System.in));
                    out=new PrintWriter(soc.getOutputStream(),true);
                    while(true)
                    {
                        str1=br1.readLine();
                        out.println(str1);
                    }             }
                catch(Exception e)
                {}}}
        public static void main(String[] args)
        {
            new ChatServer();
        }}
