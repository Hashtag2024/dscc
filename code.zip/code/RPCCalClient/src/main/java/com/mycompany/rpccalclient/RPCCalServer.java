/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rpccalclient;
import java.net.*;
import java.io.*;
import java.util.*;

public class RPCCalServer {
    DatagramPacket dp;
    DatagramSocket ds;
    String str,methodName,result;
    int val1,val2;
    RPCCalServer(){
    try{
        ds=new DatagramSocket(1200);
        byte b[]=new byte[4096];
        System.out.println("Server started");
        while(true){
        dp=new DatagramPacket(b,b.length);
        ds.receive(dp);
        str=new String(dp.getData(),0,dp.getLength());
        if(str.equalsIgnoreCase("q")){
            System.exit(1);}
        else{
            StringTokenizer st=new StringTokenizer(str," ");
            int i=0;
            while(st.hasMoreElements()){
            String token=st.nextToken();
            methodName=token;
            val1=Integer.parseInt(st.nextToken());
            val2=Integer.parseInt(st.nextToken());
            } }
        System.out.println(str);
        if(methodName.equalsIgnoreCase("add")){
            result=""+add(val1,val2);}
        else if(methodName.equalsIgnoreCase("sub")){
            result=""+sub(val1,val2);}
        else if(methodName.equalsIgnoreCase("mul")){
            result=""+mul(val1,val2);}
        else if(methodName.equalsIgnoreCase("div")){
            result=""+div(val1,val2);}
        else{
            System.out.println("Enter a valid operation");}
            byte b1[]=result.getBytes();
            DatagramSocket ds1=new DatagramSocket();
            DatagramPacket dp1=new DatagramPacket(b1,b1.length,InetAddress.getLocalHost(),1300);
            System.out.println("Result: "+result+"\n");
            ds1.send(dp1);}    }   
    catch(Exception e){}    }
        public int add(int val1,int val2){
        return val1+val2;}
        public int sub(int val1,int val2){
        return val1-val2;}
        public int mul(int val1,int val2){
        return val1*val2;}
        public int div(int val1,int val2){
        return val1/val2;}
    public static void main(String[] args) {
        new RPCCalServer();    }}

