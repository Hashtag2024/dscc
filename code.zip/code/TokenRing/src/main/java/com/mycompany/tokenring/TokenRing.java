/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tokenring;

import java.net.*;
import java.io.*;
public class TokenRing {
    public static DatagramSocket ds;
    public static DatagramPacket dp;
    public static void main(String[] args) throws Exception {
        try {
 ds=new DatagramSocket(1000); }
catch(Exception e) {e.printStackTrace();}
 while(true) {
            byte buff[]=new byte[1024];
            ds.receive(dp=new DatagramPacket(buff, buff.length));
   String str=new String(dp.getData(),0,dp.getLength()); System.out.println("Message from "+str);   }}}

