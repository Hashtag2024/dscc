/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.reverseclient;
import java.net.*;
import java.io.*;
public class ReverseServer {  
    ServerSocket ss;
    Socket soc;
    BufferedReader br,br1;
    PrintWriter out;
    String str;    
    public ReverseServer(){
    try{
    ss=new ServerSocket(8765); System.out.println("Server is listening to port 8765");
soc=ss.accept();
System.out.println("Connection established!!");
  br=new BufferedReader(new InputStreamReader(System.in));
 br1=new BufferedReader(new InputStreamReader(soc.getInputStream()));
 out=new PrintWriter(soc.getOutputStream());
 while(true){
 System.out.println("Message from client");
            str=br1.readLine();
            int k=str.length();
            System.out.println(str);
            String reverse="";
            for(int i=k-1;i>=0;i--)
            { reverse=reverse+str.charAt(i);}
System.out.println("Reverse of the string is: "+reverse);
            out.println(reverse);
            out.flush();
            if(str.equals("q"))
                break;}
            soc.close();}
        catch (Exception e){}}
    public static void main(String[] args) {
        new ReverseServer(); }}

