/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.reverseclient;
import java.net.*;
import java.io.*;
public class ReverseClient { 
    Socket soc;
    BufferedReader br,br1;
    PrintWriter out;
    String str;    
    public ReverseClient(){
    try{
 soc=new Socket("127.0.0.1",8765);
 br=new BufferedReader(new InputStreamReader(System.in));
 br1=new BufferedReader(new InputStreamReader(soc.getInputStream()));
out=new PrintWriter(soc.getOutputStream());
while(true){
 System.out.println("Enter the message: ");
            str=br.readLine();
            out.println(str);
            out.flush();
 System.out.println("Message from server: ");
            str=br1.readLine();
            System.out.println(str);
            if(str.equals("q"))
                break;}
            soc.close();}
        catch (Exception e){}}
    public static void main(String[] args) {
        new ReverseClient();}}

