/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.datetimeclient;

import java.net.*;
import java.io.*;
public class DateTimeClient {
    DateTimeClient(){
        try{
            InetAddress ia=InetAddress.getLocalHost();
            DatagramSocket ds=new DatagramSocket();
DatagramSocket ds1=new DatagramSocket(1300);
System.out.println("\nDate Time Client\n");
 byte b1[]=new byte[1000];  while(true)
    {
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                String str=br.readLine();
                byte b[]=str.getBytes();
                DatagramPacket dp=new DatagramPacket(b,b.length,ia,1200);
                ds.send(dp);
                dp=new DatagramPacket(b1,b1.length);
                ds1.receive(dp);
                String s=new String(dp.getData(),0,dp.getLength());              System.out.println("\nResult="+s+"\n");
            }}
        catch(Exception e){}}
    public static void main(String[] args) {
        new DateTimeClient();}}

