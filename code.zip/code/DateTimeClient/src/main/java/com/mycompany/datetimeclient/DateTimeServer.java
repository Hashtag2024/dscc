/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.datetimeclient;

import java.net.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
public class DateTimeServer {
    DatagramPacket dp;
    DatagramSocket ds;
    String str,methodName,result;
    DateTimeServer()    {
    try{
        ds=new DatagramSocket(1200);
        byte b[]=new byte[4096];
   System.out.println("\n Date Time Server \n");
   while(true)
        {
            dp=new DatagramPacket(b,b.length);
            ds.receive(dp);
            str=new String(dp.getData(),0,dp.getLength());
            if(str.equalsIgnoreCase("q"))
                System.exit(1);
            else
            {
                StringTokenizer st=new StringTokenizer(str," ");
                int i=0;
                while(st.hasMoreTokens())
 {
       String token=st.nextToken();
       methodName=token;}}            
       Calendar c=Calendar.getInstance();
 SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yyyy");
 Date d=c.getTime();

 InetAddress ia=InetAddress.getLocalHost();

  if(methodName.equalsIgnoreCase("date"))
      result=""+dateFormat.format(d);
  else if(methodName.equalsIgnoreCase("time"))
  {
                result=""+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
    }
            byte b1[]=result.getBytes();
            DatagramSocket ds1=new DatagramSocket();
DatagramPacket dp1=new DatagramPacket(b1,b1.length,ia,1300); System.out.println("result:"+result+"\n");
            ds1.send(dp1);
            }}
    catch(Exception e){}}
    public static void main(String[] args) {
        new DateTimeServer();}}

