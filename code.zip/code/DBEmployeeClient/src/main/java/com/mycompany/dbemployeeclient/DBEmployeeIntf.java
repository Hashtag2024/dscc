/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.dbemployeeclient;

import java.rmi.*;
public interface DBEmployeeIntf extends Remote
{
    public String getData(String s, String db) throws RemoteException;
}
