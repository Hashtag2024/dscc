/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.dbemployeeclient;

import java.rmi.*;
import java.io.*;

public class DBEmployeeClient
{
    public static void main(String[] args)
    {
         String db="", sql="", ch="", ch1="", res="";
        try 
        {
            BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
  //          while(true)
   //         {
                System.out.println("Retrieve College Information.");
                db="employee1";
                
                    ch1=br.readLine();
                     sql="select * from employeeinfo";
                    
                    
            
                
            DBEmployeeIntf id=(DBEmployeeIntf)Naming.lookup("rmi://localhost:1099/DBConn");
                res=id.getData(sql,db);
                System.out.println(res);
        }
    //}
        catch (Exception e)
        {
            e.printStackTrace();
        } 
}

}


