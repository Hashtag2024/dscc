/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.eqsolverclient;

import java.rmi.*;
import java.io.*;
public class EqSolverClient {
    public static void main(String[] args) {
        try {
            int num1=0, num2=0, res=0,choice;
            EqSolverInterface object=(EqSolverInterface)Naming.lookup("hello");
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Equations:-");
            System.out.println("1. (a-b)2");
            System.out.println("2. (a+b)2");
            System.out.println("3. (a-b)3");
            System.out.println("4. (a+b)3");
            System.out.println("5. Exit");
                     while (true)
            {      System.out.println("Choose the equation: ");
             choice=Integer.parseInt(br.readLine());
                if(choice<=4)
                {
                System.out.println("Enter the values of a and b");
                num1=Integer.parseInt(br.readLine());
      num2=Integer.parseInt(br.readLine());
                }
                switch(choice)
                {      case 1:{
           res=object.solveEq1(num1,num2);
               System.out.println("Result is: "+res); 
                        break;}
                    case 2:
                    {res=object.solveEq2(num1,num2);  
                        System.out.println("Result is: "+res); 
                     break;}
                      case 3:
                    {res=object.solveEq3(num1,num2);
                        System.out.println("Result is: "+res);              break;}      case 4:
                    {res=object.solveEq4(num1,num2);
                        System.out.println("Result is: "+res);              
                       break;} case 5:
                    {     System.exit(0); 
                        break;}
                    default:
                    { System.out.println("Invalid option");        break;    }   
                }         }     }
        catch(Exception e) {}  }}

