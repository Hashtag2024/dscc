/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.eqsolverclient;

import java.rmi.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
public interface EqSolverInterface extends Remote{
    public int solveEq1(int a, int b) throws RemoteException;
    public int solveEq2(int a, int b) throws RemoteException;
    public int solveEq3(int a, int b) throws RemoteException;
    public int solveEq4(int a, int b) throws RemoteException; }

