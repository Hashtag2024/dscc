/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eqsolverclient;

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
public class EquationSolverRMI extends UnicastRemoteObject implements EqSolverInterface {
    public EquationSolverRMI() throws RemoteException {}
        public int solveEq1(int a,int b) throws RemoteException {
            int ans=(a*a)-(2*a*b)+(b*b);
            return ans;      }
        public int solveEq2(int a,int b) throws RemoteException {
            int ans=(a*a)+(2*a*b)+(b*b);
            return ans;     }
        public int solveEq3(int a,int b) throws RemoteException {
            int ans=(a*a*a)-(3*a*a*b)+(3*a*b*b)-(b*b*b);      return ans;     }
        public int solveEq4(int a,int b) throws RemoteException {            int ans=(a*a*a)+(3*a*a*b)+(3*a*b*b)+(b*b*b);
            return ans;     }   }

