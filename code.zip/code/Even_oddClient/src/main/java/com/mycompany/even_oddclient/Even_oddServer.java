/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.even_oddclient;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Even_oddServer {
    ServerSocket ss;
    Socket soc;
    BufferedReader br, br1;
    PrintWriter out;
    String str;
    
    public Even_oddServer() {
        try {
            ss = new ServerSocket(8765);
            System.out.println("Server is listening to port 8765");
            soc = ss.accept();
            System.out.println("Connection Established");
            br = new BufferedReader(new InputStreamReader(System.in));
            br1 = new BufferedReader(new InputStreamReader(soc.getInputStream()));
            out = new PrintWriter(soc.getOutputStream());  
            
            while (true) {
                System.out.println("Message from client");
                str = br1.readLine();
                System.out.println(str);
                
                try {
                    int num = Integer.parseInt(str);
                    if (num % 2 == 0) {
                        out.println("The number " + num + " is even.");
                    } else {
                        out.println("The number " + num + " is odd.");
                    }
                } catch (NumberFormatException e) {
                    out.println("Invalid number");
                }
                
                out.flush();
                if (str.equals("q"))
                    break;            
            }
            soc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        new Even_oddServer();
    }    
}