/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.palinclient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class PalinServer {
     ServerSocket ss;
    Socket soc;
    BufferedReader br,br1;
    PrintWriter out;
    String str;
    public PalinServer()
   {
    try{
        ss=new ServerSocket(8765);
        System.out.println("Server is listening to port 8765");
        soc=ss.accept();
        System.out.println("Connection Established");
         br=new BufferedReader(new InputStreamReader(System.in));
         br1=new BufferedReader(new InputStreamReader(soc.getInputStream()));
         out=new PrintWriter(soc.getOutputStream());  
          
         while(true)
         {
             System.out.println("Message from client");
             str=br1.readLine();
             int k=str.length();
             System.out.println(str);
             int left=0, right=k-1, flag=1;
             while(left<=right)
             {
                 if(str.charAt(left)!=(str.charAt(right)))
                 {
                     flag=0;
                     break;
                 }
                 else
                 {
                     left++; right--;
                 }
             }
             if(flag==0)
                 System.out.println("Not a palindrome string");
             else
                 System.out.println("Is a palindrome string");
             out.println(str);
             out.flush();
             if(str.equals("q"))
                 break;            
         }
    }
    catch(Exception e)
    {}
   }
    public static void main(String[] args)
            {
                new PalinServer();
            }    
}
